chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
  const url = tabs[0] && tabs[0].url;
  const v = document.getElementById('verdict');
  if (!url || !/^https?:/.test(url)) { v.textContent = 'Not scoreable'; return; }
  document.getElementById('url').textContent = url;
  chrome.runtime.sendMessage({ type: 'scoreUrl', url }, resp => {
    if (!resp || resp.pLegit == null) { v.textContent = 'Error: ' + (resp && resp.error || 'no score'); return; }
    const p = resp.pLegit;
    const phishing = p < 0.5;
    v.textContent = phishing ? '⚠ Likely phishing' : '✓ Looks legitimate';
    v.className = phishing ? 'bad' : 'ok';
    const fill = document.getElementById('fill');
    fill.style.width = Math.round(p * 100) + '%';
    fill.style.background = phishing ? '#d32f2f' : '#2e7d32';
    v.textContent += `  (${(p * 100).toFixed(1)}% legit)`;
  });
});
